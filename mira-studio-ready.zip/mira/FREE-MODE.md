# Mira Director — Free Mode

Mira defaults to a browser-first workflow that does not call xAI/Grok and does not require an API key or API credits.

## What works without credits

1. Add a product photo or use the sample bottle.
2. Fill/adjust product details.
3. Generate the shot plan locally.
4. Approve the reference still locally (the original photo is preserved).
5. Render a short preview film locally with Canvas + MediaRecorder.
6. Save the WebM film.

## Cloud/Grok mode

Cloud generation is deliberately opt-in. It requires `VITE_MIRA_FREE_MODE=false` and a server-side `XAI_API_KEY`. Never put the key in client code.

## Build

The normal `npm run build` is now database-free. The old database migration command is available separately as `npm run build:with-db` for projects that explicitly add a database schema.
