import { Film, Plus } from "lucide-react";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { bootAi } from "@/lib/director";
import { useStudio } from "@/lib/store";
import { ChatPanel } from "./chat-panel";
import { Library } from "./library";
import { MiraMark } from "./mark";
import { Stage } from "./stage";

export function Studio() {
  const setHydrated = useStudio((s) => s.setHydrated);
  const newFilm = useStudio((s) => s.newFilm);
  const setLibraryOpen = useStudio((s) => s.setLibraryOpen);
  const films = useStudio((s) => s.films);
  const phase = useStudio((s) => s.phase);
  const freeMode = useStudio((s) => s.freeMode);

  useEffect(() => {
    setHydrated(true);
    void bootAi();
  }, [setHydrated]);

  return (
    <TooltipProvider>
      <div className="flex h-dvh min-h-0 flex-col bg-background text-foreground">
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-border px-4 md:px-6">
          <div className="flex items-center gap-2.5">
            <MiraMark className="size-7 text-primary" />
            <div className="leading-none">
              <p className="font-display text-xl tracking-display">Mira</p>
              <p className="text-xs uppercase tracking-label text-subtle">Director</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <StatusDot phase={phase} freeMode={freeMode} />
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon-sm" onClick={() => setLibraryOpen(true)} aria-label="Open library">
                  <Film />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Library{films.length ? ` · ${films.length}` : ""}</TooltipContent>
            </Tooltip>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon-sm" onClick={() => newFilm()} aria-label="New film">
                  <Plus />
                </Button>
              </TooltipTrigger>
              <TooltipContent>New film</TooltipContent>
            </Tooltip>
          </div>
        </header>

        <div className="grid min-h-0 flex-1 grid-rows-2 lg:grid-cols-[minmax(20rem,24rem)_1fr] lg:grid-rows-none">
          <div className="order-2 min-h-0 border-t border-border lg:order-1 lg:border-r lg:border-t-0">
            <ChatPanel />
          </div>
          <div className="order-1 min-h-0 lg:order-2">
            <Stage />
          </div>
        </div>
        <Library />
      </div>
    </TooltipProvider>
  );
}

function StatusDot({ phase, freeMode }: { phase: string; freeMode: boolean }) {
  const label =
    phase === "ready"
      ? "Film ready"
      : phase === "rendering"
        ? "Animating"
        : phase === "still"
          ? "Still ready"
          : phase === "planned"
            ? "Plan ready"
            : phase === "error"
              ? "Needs attention"
              : "Intake";
  const color =
    phase === "ready"
      ? "bg-ok"
      : phase === "error"
        ? "bg-destructive"
        : phase === "rendering"
          ? "bg-primary mira-pulse"
          : "bg-subtle";
  return (
    <span className="mr-2 hidden items-center gap-2 text-xs uppercase tracking-label text-muted-foreground sm:inline-flex" title={freeMode ? "No external AI API calls" : "Cloud AI mode"}>
      <span className={`size-1.5 rounded-full ${color}`} />
      {freeMode ? "Free local" : label}
    </span>
  );
}
