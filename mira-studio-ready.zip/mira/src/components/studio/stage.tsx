import { Check, Clapperboard, Download, ImagePlus, Loader2, RefreshCw, Sparkles } from "lucide-react";
import { useRef, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ASPECTS, ASPECT_LABELS, DURATIONS, FORMS, FORM_LABELS, type Aspect, type Duration, type ProductForm } from "@/lib/film";
import { animateStill, ingestFile, ingestSample, runSampleDemo, shootStill, writePlan } from "@/lib/director";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

const STEPS = ["Brief", "Plan", "Still", "Film"] as const;

export function Stage() {
  const image = useStudio((s) => s.imageDataUri);
  const still = useStudio((s) => s.stillDataUri);
  const video = useStudio((s) => s.videoUrl);
  const plan = useStudio((s) => s.plan);
  const phase = useStudio((s) => s.phase);
  const busy = useStudio((s) => s.busy);
  const error = useStudio((s) => s.error);
  const intake = useStudio((s) => s.intake);
  const patchIntake = useStudio((s) => s.patchIntake);
  const [over, setOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const frame = still || image;
  const ratio =
    (plan?.aspect ?? intake.aspect) === "16:9"
      ? "16 / 9"
      : (plan?.aspect ?? intake.aspect) === "1:1"
        ? "1 / 1"
        : "9 / 16";

  function onFiles(files: FileList | null) {
    const file = files?.[0];
    if (file && file.type.startsWith("image/")) void ingestFile(file);
  }

  const currentStep = phase === "ready" ? 4 : phase === "rendering" ? 4 : phase === "still" ? 3 : phase === "planned" ? 2 : 1;

  return (
    <section className="flex h-full min-h-0 flex-col bg-well">
      <div className="flex items-center justify-between gap-3 border-b border-border bg-background px-4 py-2.5 md:px-5">
        <div className="flex min-w-0 items-center gap-1.5 overflow-x-auto no-scrollbar">
          {STEPS.map((step, index) => {
            const done = index + 1 < currentStep || (index + 1 === 4 && phase === "ready");
            const active = index + 1 === currentStep && phase !== "ready";
            return (
              <div key={step} className="flex shrink-0 items-center gap-1.5 text-[11px] uppercase tracking-label">
                <span className={cn(
                  "flex size-5 items-center justify-center rounded-full border text-[10px]",
                  done && "border-ok/60 bg-ok/15 text-ok",
                  active && "border-primary bg-primary text-primary-foreground",
                  !done && !active && "border-border text-subtle",
                )}>
                  {done ? <Check className="size-3" /> : index + 1}
                </span>
                <span className={cn(active ? "text-foreground" : "text-subtle")}>{step}</span>
                {index < STEPS.length - 1 ? <span className="mx-1 text-border">/</span> : null}
              </div>
            );
          })}
        </div>
        {plan ? <span className="hidden shrink-0 text-xs tabular-nums text-subtle sm:block">{plan.duration}s · {plan.aspect}</span> : null}
      </div>

      <div
        className={cn("relative min-h-0 flex-1 p-3 md:p-5", over && "bg-accent/40")}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); onFiles(e.dataTransfer.files); }}
      >
        <Viewfinder>
          {video ? (
            <video key={video} src={video} className="h-full w-full object-contain" style={{ aspectRatio: ratio }} controls autoPlay playsInline poster={still ?? undefined} />
          ) : frame ? (
            <img src={frame} alt={still ? "Approved still" : "Product photograph"} className="h-full w-full object-contain" style={{ aspectRatio: ratio }} />
          ) : (
            <EmptyStage onPick={() => inputRef.current?.click()} onSample={() => void ingestSample()} onDemo={() => void runSampleDemo()} />
          )}
          {phase === "rendering" ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/65 backdrop-blur-[2px]">
              <div className="rounded-full border border-border bg-card/90 p-3 shadow-lg"><Loader2 className="size-6 animate-spin text-primary" /></div>
              <p className="mt-3 font-display text-xl italic text-foreground">Animating</p>
              <p className="mt-1 text-xs text-muted-foreground">The final film is rendering. You can keep this tab open.</p>
            </div>
          ) : null}
        </Viewfinder>
        <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { onFiles(e.target.files); e.target.value = ""; }} />
      </div>

      <div className="border-t border-border bg-background px-4 py-3 md:px-6 md:py-4">
        <div className="hidden lg:block">
          <div className="flex flex-wrap items-end gap-3">
            <Field label="Name"><Input value={intake.productName} placeholder="As it appears on the pack" className="h-10 min-w-48" onChange={(e) => patchIntake({ productName: e.target.value })} /></Field>
            <Field label="Form"><ChipRow options={FORMS.map((f) => ({ value: f, label: FORM_LABELS[f] }))} value={intake.form} onChange={(v) => patchIntake({ form: v as ProductForm })} /></Field>
            <Field label="Length"><ChipRow options={DURATIONS.map((d) => ({ value: String(d), label: `${d}s` }))} value={String(intake.duration)} onChange={(v) => patchIntake({ duration: Number(v) as Duration })} /></Field>
            <Field label="Frame"><ChipRow options={ASPECTS.map((a) => ({ value: a, label: ASPECT_LABELS[a] }))} value={intake.aspect} onChange={(v) => patchIntake({ aspect: v as Aspect })} /></Field>
          </div>
          <Field label="Claims on screen" className="mt-3"><Input value={intake.claims} placeholder="Verbatim from the pack or listing" onChange={(e) => patchIntake({ claims: e.target.value })} /></Field>
          <Field label="Look, up close" className="mt-3"><Input value={intake.look} placeholder="Material, finish, how it behaves" onChange={(e) => patchIntake({ look: e.target.value })} /></Field>
        </div>

        <div className="lg:hidden -mx-1 overflow-x-auto pb-1 no-scrollbar">
          <div className="flex w-max gap-1.5 px-1">
            {DURATIONS.map((d) => <Pill key={d} active={intake.duration === d} onClick={() => patchIntake({ duration: d })}>{d}s</Pill>)}
            <span className="mx-1 w-px bg-border" />
            {ASPECTS.map((a) => <Pill key={a} active={intake.aspect === a} onClick={() => patchIntake({ aspect: a })}>{a}</Pill>)}
          </div>
        </div>

        {plan ? (
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1 no-scrollbar lg:mt-4">
            {plan.setups.map((s, i) => (
              <div key={`${s.family}-${i}`} className="min-w-[210px] rounded-lg bg-secondary px-3 py-2.5 shadow-[var(--shadow-border)] lg:min-w-0 lg:flex-1">
                <p className="text-[10px] font-medium uppercase tracking-label text-subtle">{String(i + 1).padStart(2, "0")} · {s.family} · {s.seconds}s</p>
                <p className="mt-1 line-clamp-2 text-sm leading-snug text-foreground/90">{s.action}</p>
              </div>
            ))}
          </div>
        ) : null}

        {error ? <p className="mt-3 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p> : null}

        <div className="mt-3 flex gap-2 overflow-x-auto pb-0.5 no-scrollbar md:mt-4">
          <Button variant="secondary" className="shrink-0" disabled={Boolean(busy) || !image} onClick={() => void writePlan()}><Clapperboard /> Write plan</Button>
          <Button variant="secondary" className="shrink-0" disabled={Boolean(busy) || !plan} onClick={() => void shootStill()}><RefreshCw /> {still ? "Reshoot still" : "Shoot still"}</Button>
          <Button className="shrink-0" disabled={Boolean(busy) || !still} onClick={() => void animateStill()}>{busy && phase === "rendering" ? <Loader2 className="animate-spin" /> : <Sparkles />} Animate still</Button>
          {video ? <Button variant="secondary" className="shrink-0" onClick={() => downloadVideo(video, plan?.productName || intake.productName || "mira-film")}><Download /> Save film</Button> : null}
        </div>
      </div>
    </section>
  );
}

function downloadVideo(url: string, name: string) {
  const a = document.createElement("a");
  a.href = url;
  a.download = `${name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "mira-film"}.webm`;
  a.target = "_blank";
  a.rel = "noreferrer";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return <div className={cn("flex min-w-0 flex-col gap-1.5", className)}><span className="text-xs font-medium uppercase tracking-label text-subtle">{label}</span>{children}</div>;
}

function ChipRow({ options, value, onChange }: { options: { value: string; label: string }[]; value: string; onChange: (v: string) => void }) {
  return <div className="flex flex-wrap gap-1.5">{options.map((o) => <Pill key={o.value} active={o.value === value} onClick={() => onChange(o.value)}>{o.label}</Pill>)}</div>;
}

function Pill({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return <button type="button" onClick={onClick} className={cn("h-10 rounded-full px-3 text-sm transition-[background-color,color,transform] duration-[var(--motion-quick)] active:scale-[0.96]", active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground shadow-[var(--shadow-border)] hover:text-foreground")}>{children}</button>;
}

function Viewfinder({ children }: { children: ReactNode }) {
  return <div className="relative flex h-full min-h-56 items-center justify-center overflow-hidden rounded-xl bg-card md:min-h-72"><Corner className="left-3 top-3 border-l border-t" /><Corner className="right-3 top-3 border-r border-t" /><Corner className="bottom-3 left-3 border-b border-l" /><Corner className="bottom-3 right-3 border-b border-r" /><div className="flex h-full w-full items-center justify-center p-4 md:p-10">{children}</div></div>;
}

function Corner({ className }: { className: string }) { return <span aria-hidden className={cn("pointer-events-none absolute size-6 border-primary/70", className)} />; }

function EmptyStage({ onPick, onSample, onDemo }: { onPick: () => void; onSample: () => void; onDemo: () => void }) {
  return <div className="flex max-w-sm flex-col items-center px-4 text-center"><ImagePlus className="size-6 text-muted-foreground" /><h2 className="mt-4 font-display text-2xl leading-tight tracking-display text-foreground md:text-3xl">Drop a product photograph</h2><p className="mt-2 text-sm leading-relaxed text-muted-foreground">Use a clean product photo. Mira will turn the reference into a controlled still, then animate that approved frame.</p><div className="mt-5 flex flex-wrap justify-center gap-2"><Button onClick={onPick}>Choose a photo</Button><Button variant="secondary" onClick={onSample}>Try the sample bottle</Button><Button variant="ghost" onClick={onDemo}>Run full demo</Button></div></div>;
}
