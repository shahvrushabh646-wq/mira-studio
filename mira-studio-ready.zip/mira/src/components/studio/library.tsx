import { Film, Play, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStudio } from "@/lib/store";

export function Library() {
  const open = useStudio((s) => s.libraryOpen);
  const films = useStudio((s) => s.films);
  const setOpen = useStudio((s) => s.setLibraryOpen);
  const load = useStudio((s) => s.loadFilm);
  const remove = useStudio((s) => s.removeFilm);
  if (!open) return null;

  return <div className="fixed inset-0 z-40 flex justify-end">
    <button type="button" aria-label="Close library" onClick={() => setOpen(false)} className="absolute inset-0 bg-background/60 backdrop-blur-sm" />
    <aside className="relative flex h-full w-full max-w-md flex-col border-l border-border bg-card shadow-2xl">
      <header className="flex items-center justify-between border-b border-border px-5 py-4">
        <div><p className="text-xs font-medium uppercase tracking-label text-subtle">Library</p><h2 className="font-display text-2xl tracking-display">Films</h2></div>
        <Button variant="ghost" size="icon-sm" onClick={() => setOpen(false)} aria-label="Close library"><X /></Button>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto p-4">
        {films.length === 0 ? <div className="flex h-full flex-col items-center justify-center px-6 text-center"><Film className="size-8 text-subtle" /><p className="mt-4 text-sm text-muted-foreground">Your finished films will appear here. They stay on this device.</p></div> : <ul className="grid gap-3 sm:grid-cols-2">
          {films.map((f) => <li key={f.id} className="overflow-hidden rounded-xl bg-secondary shadow-[var(--shadow-border)]">
            <button type="button" onClick={() => load(f.id)} className="group block w-full text-left">
              <div className="relative overflow-hidden bg-black"><img src={f.stillDataUri} alt={`${f.productName} still`} className="aspect-portrait w-full object-cover transition-transform duration-300 group-hover:scale-[1.02]" />{f.videoUrl ? <span className="absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-black/70 px-2 py-1 text-[10px] uppercase tracking-label text-white"><Play className="size-3 fill-current" /> Ready</span> : null}</div>
              <div className="px-3 py-3"><p className="truncate text-sm font-medium">{f.productName}</p><p className="mt-0.5 text-xs tabular-nums text-muted-foreground">{f.duration}s · {f.aspect}</p></div>
            </button>
            <div className="flex justify-end border-t border-border px-3 py-2"><button type="button" className="flex items-center gap-1.5 text-xs text-subtle hover:text-destructive" onClick={() => remove(f.id)}><Trash2 className="size-3.5" /> Remove</button></div>
          </li>)}
        </ul>}
      </div>
    </aside>
  </div>;
}
