export function MiraMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
      className={className}
    >
      <circle cx="16" cy="16" r="13.5" stroke="currentColor" strokeWidth="1.25" />
      <circle cx="16" cy="16" r="8" stroke="currentColor" strokeWidth="1.25" />
      <circle cx="16" cy="16" r="2.4" fill="currentColor" />
      <line x1="24.8" y1="16" x2="28.6" y2="16" stroke="currentColor" strokeWidth="1.25" />
      <line x1="20.4" y1="23.62" x2="22.3" y2="26.91" stroke="currentColor" strokeWidth="1.25" />
      <line x1="11.6" y1="23.62" x2="9.7" y2="26.91" stroke="currentColor" strokeWidth="1.25" />
      <line x1="7.2" y1="16" x2="3.4" y2="16" stroke="currentColor" strokeWidth="1.25" />
      <line x1="11.6" y1="8.38" x2="9.7" y2="5.09" stroke="currentColor" strokeWidth="1.25" />
      <line x1="20.4" y1="8.38" x2="22.3" y2="5.09" stroke="currentColor" strokeWidth="1.25" />
    </svg>
  );
}
