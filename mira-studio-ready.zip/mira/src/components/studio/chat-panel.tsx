import { ArrowUp, Loader2, Paperclip } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { handleAction, ingestFile, sendToMira } from "@/lib/director";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export function ChatPanel() {
  const messages = useStudio((s) => s.messages);
  const busy = useStudio((s) => s.busy);
  const aiOk = useStudio((s) => s.aiOk);
  const freeMode = useStudio((s) => s.freeMode);
  const [draft, setDraft] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, busy]);

  async function submit() {
    const text = draft.trim();
    if (!text || busy) return;
    setDraft("");
    await sendToMira(text);
  }

  return (
    <section className="flex h-full min-h-0 flex-col bg-background">
      <div className="min-h-0 flex-1 overflow-y-auto px-5 py-5 md:px-6">
        <ol className="flex flex-col gap-6">
          {messages.map((m) => (
            <li
              key={m.id}
              className={cn(
                "max-w-prose",
                m.role === "user" ? "self-end" : "self-start",
              )}
            >
              {m.role === "assistant" ? (
                <p className="text-xs font-medium uppercase tracking-label text-subtle">
                  Mira
                </p>
              ) : null}
              <div
                className={cn(
                  "mt-1.5 whitespace-pre-wrap text-sm leading-relaxed md:text-base",
                  m.role === "user"
                    ? "rounded-lg bg-secondary px-3.5 py-2.5 text-foreground shadow-[var(--shadow-border)]"
                    : "text-foreground/90",
                )}
              >
                {m.text}
              </div>
              {m.actions?.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {m.actions.map((a) => (
                    <Button
                      key={a.id}
                      size="sm"
                      disabled={Boolean(busy)}
                      onClick={() => handleAction(a.kind, a.label)}
                    >
                      {a.label}
                    </Button>
                  ))}
                </div>
              ) : null}
              {m.suggestions?.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {m.suggestions.map((chip) => (
                    <button
                      key={chip}
                      type="button"
                      disabled={Boolean(busy)}
                      onClick={() => handleAction("chip", chip)}
                      className="h-9 rounded-full px-3 text-sm text-muted-foreground shadow-[var(--shadow-border)] transition-[background-color,color,transform] duration-[var(--motion-quick)] hover:bg-accent hover:text-foreground active:scale-[0.96] disabled:opacity-40"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              ) : null}
            </li>
          ))}
          {busy ? (
            <li className="self-start">
              <p className="mira-shimmer font-display text-lg italic text-muted-foreground">
                {busy}
              </p>
            </li>
          ) : null}
          <div ref={endRef} />
        </ol>
      </div>

      <form
        className="border-t border-border p-3 md:p-4"
        onSubmit={(e) => {
          e.preventDefault();
          void submit();
        }}
      >
        {freeMode ? (
          <p className="mb-2 px-1 text-xs text-muted-foreground">
            Free local mode · no Grok/xAI API credits used. Your photograph stays in this browser.
          </p>
        ) : aiOk === false ? (
          <p className="mb-2 px-1 text-xs text-muted-foreground">
            Cloud AI is unavailable. Configure an xAI API key only if you want paid Grok API generation.
          </p>
        ) : null}
        <div className="flex items-end gap-2 rounded-xl bg-secondary p-2 shadow-[var(--shadow-border)]">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (file) void ingestFile(file);
            }}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            className="shrink-0"
            aria-label="Attach a product photograph"
            onClick={() => fileRef.current?.click()}
          >
            <Paperclip />
          </Button>
          <Textarea
            rows={1}
            value={draft}
            placeholder="Talk to Mira"
            className="min-h-10 max-h-32 flex-1 border-0 bg-transparent shadow-none focus-visible:ring-0"
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void submit();
              }
            }}
          />
          <Button
            type="submit"
            size="icon-sm"
            disabled={!draft.trim() || Boolean(busy)}
            aria-label="Send"
            className="shrink-0"
          >
            {busy ? <Loader2 className="animate-spin" /> : <ArrowUp />}
          </Button>
        </div>
      </form>
    </section>
  );
}
