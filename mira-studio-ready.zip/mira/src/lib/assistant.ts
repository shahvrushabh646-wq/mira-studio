import {
  type ActionFamily,
  type Aspect,
  type Duration,
  type Intake,
  type Pacing,
  type ProductForm,
  type ShotPlan,
  allowedFamilies,
  buildFilmPrompt,
  buildStillPrompt,
  defaultSurface,
  secondsForSetups,
  setupCount,
  splitClaims,
  CAMERAS,
  DURATIONS,
  ASPECTS,
  FORMS,
} from "./film";

export const MIRA_SYSTEM = `You are Mira, a personal film director. You make one e-commerce PRODUCT film at a time. The product performs. No presenter, no voiceover, no person to camera. You never invent a claim, a product fact, or a logo.

Voice: calm, precise, editorial. Short paragraphs. No emoji. No hype.

You are also a personal assistant for this studio: you remember what the person has told you in this conversation, you can help tighten claims, name the product correctly, choose a surface, and talk through shot ideas. You do not generate motion until they approve a still.

Intake — seven things block generation:
1. Product name, exactly as the brand writes it
2. A clean isolated product photograph (already attached when present)
3. Product form / material (rigid, liquid, spread, powder, pieces, fabric, jewellery)
4. A close visual or material detail
5. Claims or selling points, verbatim from their source — the only on-screen text allowed
6. Duration (6, 10 or 15 seconds)
7. Aspect ratio (9:16, 1:1 or 16:9)

Ask in batches of three or four, in prose. Do not dump eighteen questions. Offer sensible defaults: 10 seconds, 9:16, fast-cut-energy, a contained tabletop surface. Never default to slow motion.

Rules you must not break:
- Do not look a product up or guess a catalogue.
- Do not write on-screen text that is not a verbatim claim they gave you.
- Do not ask the generator to draw a logo.
- Filter action families by physical form. A rigid bottle cannot be poured; a garment cannot be crunched; a liquid cannot be stacked.
- Each setup is a NEW action with a different camera move. Three setups is the floor.
- Scope sound. Ambient only, plus at most one interaction sound.
- If they ask for a talking-head, UGC presenter, or narrated voiceover, say plainly that you do not make those films.

When you reply, ALWAYS return a single JSON object:
{
  "message": "your spoken reply, markdown-light, no JSON inside",
  "intakePatch": { optional partial fields you extracted },
  "suggestions": ["short chip", "short chip"],
  "readyToPlan": boolean
}

intakePatch may include: productName, form, look, claims, duration (6|10|15), aspect ("9:16"|"1:1"|"16:9"), surface, edible (boolean).
readyToPlan is true only when name, form, look, claims, duration and aspect are all known (from this turn or earlier context).
suggestions are 2–4 short replies the person could tap. Empty array if none.
`;

export const PLAN_SYSTEM = `You design one product film. Return JSON only.

The product performs; no people, no voiceover, no invented claims, no logo.

Schema:
{
  "archetype": "string",
  "pacing": "fast-cut-energy" | "speed-ramp" | "product-spin" | "snap-macro" | "drone-sweep" | "stop-motion-pop",
  "surface": "contained tabletop surface, not a landscape",
  "productDescription": "one or two sentences: shape, packaging, colour, material, how it behaves",
  "hook": "why someone stops scrolling",
  "valueAngle": "the buying fact in the brand's words",
  "setups": [
    {
      "family": "one action family",
      "action": "one new physical action, concrete",
      "camera": "one camera move, unique in this film",
      "light": "direction and quality"
    }
  ],
  "onScreenText": {
    "setupIndex": 0,
    "intro": "verbatim small line from claims or empty",
    "accent": "verbatim large line from claims",
    "colour": "a colour that fits the product, not a chip",
    "placement": "where the reserved space is"
  } | null,
  "sound": "ambient description; scope any interaction sound to one setup"
}

Constraints:
- Number of setups is given. None of the families may repeat. No alike pairs: crunch+slice, impact+tumble, pour+squeeze, reveal+rise, open+unbox.
- Families must be physically possible for this form. Use only the allowed list provided.
- First setup should establish the product (orbit, reveal, or macro) unless the product enters by drop/rise.
- Do not invent claims. On-screen text is only from the claims string; set onScreenText to null if they asked for none or claims are empty.
- Camera moves must all be different.
- drone-sweep is tabletop scale only.
`;

type AssistantJson = {
  message?: string;
  intakePatch?: Partial<Intake> & { duration?: number; aspect?: string; form?: string };
  suggestions?: string[];
  readyToPlan?: boolean;
};

export function parseAssistant(raw: string): {
  message: string;
  intakePatch: Partial<Intake>;
  suggestions: string[];
  readyToPlan: boolean;
} {
  const json = extractJson(raw);
  if (!json) {
    return { message: raw.trim(), intakePatch: {}, suggestions: [], readyToPlan: false };
  }
  const parsed = json as AssistantJson;
  const patch = normalizePatch(parsed.intakePatch ?? {});
  return {
    message: (parsed.message ?? "").trim() || "Tell me a little more about the product.",
    intakePatch: patch,
    suggestions: Array.isArray(parsed.suggestions)
      ? parsed.suggestions.map(String).slice(0, 4)
      : [],
    readyToPlan: Boolean(parsed.readyToPlan),
  };
}

function normalizePatch(p: AssistantJson["intakePatch"]): Partial<Intake> {
  if (!p) return {};
  const out: Partial<Intake> = {};
  if (typeof p.productName === "string" && p.productName.trim()) {
    out.productName = p.productName.trim();
  }
  if (typeof p.form === "string" && (FORMS as readonly string[]).includes(p.form)) {
    out.form = p.form as ProductForm;
  }
  if (typeof p.look === "string" && p.look.trim()) out.look = p.look.trim();
  if (typeof p.claims === "string" && p.claims.trim()) out.claims = p.claims.trim();
  if (typeof p.surface === "string" && p.surface.trim()) out.surface = p.surface.trim();
  if (typeof p.edible === "boolean") out.edible = p.edible;
  if (typeof p.duration === "number" && (DURATIONS as readonly number[]).includes(p.duration)) {
    out.duration = p.duration as Duration;
  }
  if (typeof p.aspect === "string" && (ASPECTS as readonly string[]).includes(p.aspect)) {
    out.aspect = p.aspect as Aspect;
  }
  return out;
}

type PlanJson = {
  archetype?: string;
  pacing?: string;
  surface?: string;
  productDescription?: string;
  hook?: string;
  valueAngle?: string;
  setups?: {
    family?: string;
    action?: string;
    camera?: string;
    light?: string;
  }[];
  onScreenText?: {
    setupIndex?: number;
    intro?: string;
    accent?: string;
    colour?: string;
    placement?: string;
  } | null;
  sound?: string;
};

export function assemblePlan(intake: Intake, raw: string): ShotPlan {
  const json = (extractJson(raw) ?? {}) as PlanJson;
  const form = intake.form || "rigid";
  const n = setupCount(intake.duration);
  const allowed = allowedFamilies(form, intake.edible);
  const used = new Set<ActionFamily>();
  const usedCam = new Set<string>();
  const secs = secondsForSetups(intake.duration, n);

  const setups = Array.from({ length: n }, (_, i) => {
    const src = json.setups?.[i];
    let family = (src?.family as ActionFamily) || allowed[i % allowed.length];
    if (!allowed.includes(family) || used.has(family)) {
      family = allowed.find((f) => !used.has(f)) ?? allowed[0];
    }
    used.add(family);
    let camera = (src?.camera || "").trim() || CAMERAS[i % CAMERAS.length];
    if (usedCam.has(camera)) {
      camera = CAMERAS.find((c) => !usedCam.has(c)) ?? camera;
    }
    usedCam.add(camera);
    return {
      family,
      seconds: secs[i],
      action:
        (src?.action || "").trim() ||
        defaultAction(family, intake.productName || "the product"),
      camera,
      light: (src?.light || "").trim() || "soft daylight from the upper left",
    };
  });

  const claims = splitClaims(intake.claims);
  const text =
    json.onScreenText === null
      ? null
      : claims
        ? {
            setupIndex: Math.min(
              Math.max(json.onScreenText?.setupIndex ?? Math.min(1, n - 1), 0),
              n - 1,
            ),
            intro: (json.onScreenText?.intro || claims.intro).trim(),
            accent: (json.onScreenText?.accent || claims.accent).trim(),
            colour: json.onScreenText?.colour?.trim() || "warm off-white",
            placement:
              json.onScreenText?.placement?.trim() || "in the lower third, with empty soft space",
          }
        : null;

  const pacing = (
    ["fast-cut-energy", "speed-ramp", "product-spin", "snap-macro", "drone-sweep", "stop-motion-pop"].includes(
      json.pacing ?? "",
    )
      ? json.pacing
      : "fast-cut-energy"
  ) as Pacing;

  const plan: ShotPlan = {
    productName: intake.productName,
    form,
    archetype: json.archetype?.trim() || "spin-showcase",
    pacing,
    duration: intake.duration,
    aspect: intake.aspect,
    surface: json.surface?.trim() || intake.surface || defaultSurface(form),
    productDescription:
      json.productDescription?.trim() ||
      `${intake.productName}. ${intake.look}`.trim(),
    hook: json.hook?.trim() || "rotate-and-catch-light",
    valueAngle: json.valueAngle?.trim() || claims?.accent || "key-spec-or-material",
    families: setups.map((s) => s.family),
    setups,
    onScreenText: text,
    sound:
      json.sound?.trim() ||
      "Light, clean, minimal ambient texture, no vocals. There is no interaction sound in this film anywhere.",
    stillPrompt: "",
    filmPrompt: "",
  };
  plan.stillPrompt = buildStillPrompt(plan);
  plan.filmPrompt = buildFilmPrompt(plan);
  return plan;
}

function defaultAction(family: ActionFamily, product: string): string {
  switch (family) {
    case "orbit":
      return `The camera travels around ${product}, the label rotating into full view and holding for a beat.`;
    case "macro":
      return `An extreme close-up of the material and finish of ${product}, light sliding across the surface.`;
    case "reveal":
      return `${product} comes into view as the frame finds it, already on the set.`;
    case "open":
      return `The pack of ${product} opens, showing what is inside.`;
    case "click":
      return `A precise mechanical click — a cap, latch or control on ${product} engages.`;
    case "pour":
      return `A controlled stream leaves ${product} and lands on the surface.`;
    case "drop":
      return `A single drop falls from ${product} and settles.`;
    case "wear":
      return `${product} is placed and sits as it would be worn, catching light.`;
    case "fold":
      return `${product} folds and drapes into a new shape.`;
    case "flip":
      return `${product} turns to show its other face.`;
    default:
      return `${product} performs a ${family} beat, then settles.`;
  }
}

function extractJson(raw: string): unknown | null {
  const trimmed = raw.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const candidate = fence ? fence[1].trim() : trimmed;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1));
  } catch {
    return null;
  }
}

export function intakeReady(intake: Intake, hasImage: boolean): boolean {
  return Boolean(
    hasImage &&
      intake.productName.trim() &&
      intake.form &&
      intake.look.trim() &&
      intake.claims.trim() &&
      intake.duration &&
      intake.aspect,
  );
}

export function describeIntake(intake: Intake, hasImage: boolean): string {
  const rows = [
    `productName: ${intake.productName || "(unknown)"}`,
    `form: ${intake.form || "(unknown)"}`,
    `look: ${intake.look || "(unknown)"}`,
    `claims: ${intake.claims || "(unknown)"}`,
    `duration: ${intake.duration}s`,
    `aspect: ${intake.aspect}`,
    `surface: ${intake.surface || "(default later)"}`,
    `edible: ${intake.edible}`,
    `photograph: ${hasImage ? "attached" : "missing"}`,
  ];
  return rows.join("\n");
}
