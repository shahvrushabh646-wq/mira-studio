import { assemblePlan, type Intake, type ShotPlan } from "./film";

export function isFreeMode(): boolean {
  return import.meta.env.VITE_MIRA_FREE_MODE !== "false";
}

export function localPlan(intake: Intake): ShotPlan {
  return assemblePlan(intake, JSON.stringify({
    archetype: "clean product showcase",
    pacing: "product-spin",
    surface: intake.surface || "clean tabletop surface with soft daylight",
    productDescription: `${intake.productName || "The product"}. ${intake.look || "Keep the original shape, packaging and finish faithful to the reference photograph."}`,
    hook: "clean reveal with a controlled hero finish",
    valueAngle: intake.claims?.split(/\\n|\n/)[0] || "product detail",
    setups: [],
    onScreenText: null,
    sound: "quiet ambient texture with no voiceover",
  }));
}

export function localStill(imageDataUri: string): string {
  return imageDataUri;
}

export async function renderLocalFilm(input: {
  imageDataUri: string;
  duration: number;
  aspect: string;
  productName: string;
}): Promise<string> {
  if (typeof MediaRecorder === "undefined") {
    throw new Error("Free video rendering is not supported by this browser. Use Chrome or Edge for local film export.");
  }

  const canvas = document.createElement("canvas");
  const dimensions = input.aspect === "16:9"
    ? [640, 360]
    : input.aspect === "1:1"
      ? [480, 480]
      : [360, 640];
  canvas.width = dimensions[0];
  canvas.height = dimensions[1];

  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not create the local film canvas");

  const image = await loadImage(input.imageDataUri);
  const stream = canvas.captureStream(24);
  const mimeType = pickMimeType();
  const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
  const chunks: BlobPart[] = [];

  recorder.ondataavailable = (event) => {
    if (event.data.size) chunks.push(event.data);
  };

  const stopped = new Promise<Blob>((resolve, reject) => {
    recorder.onerror = () => reject(new Error("Local film recording failed"));
    recorder.onstop = () => resolve(new Blob(chunks, { type: recorder.mimeType || "video/webm" }));
  });

  recorder.start(250);
  const started = performance.now();
  const totalMs = Math.max(3000, input.duration * 1000);

  await new Promise<void>((resolve) => {
    const draw = (now: number) => {
      const progress = Math.min(1, (now - started) / totalMs);
      drawFrame(ctx, canvas, image, progress, input.productName);
      if (progress >= 1) resolve();
      else requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);
  });

  recorder.stop();
  const blob = await stopped;
  return URL.createObjectURL(blob);
}

function drawFrame(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  image: HTMLImageElement,
  progress: number,
  productName: string,
) {
  const w = canvas.width;
  const h = canvas.height;
  const ease = progress < 0.5 ? progress * 2 : (1 - progress) * 2;
  const scale = 1.03 + ease * 0.07;
  const sourceRatio = image.width / image.height;
  const targetRatio = w / h;
  let dw = w;
  let dh = h;
  if (sourceRatio > targetRatio) dw = h * sourceRatio;
  else dh = w / sourceRatio;
  dw *= scale;
  dh *= scale;
  const x = (w - dw) / 2;
  const y = (h - dh) / 2;

  ctx.fillStyle = "#11100f";
  ctx.fillRect(0, 0, w, h);
  ctx.globalAlpha = 1;
  ctx.drawImage(image, x, y, dw, dh);

  const gradient = ctx.createLinearGradient(0, h * 0.55, 0, h);
  gradient.addColorStop(0, "rgba(0,0,0,0)");
  gradient.addColorStop(1, "rgba(0,0,0,.62)");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, w, h);

  if (productName) {
    ctx.fillStyle = "rgba(255,255,255,.92)";
    ctx.font = `${Math.max(13, Math.round(w * 0.035))}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText(productName.slice(0, 48), w / 2, h - Math.max(22, h * 0.06));
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Could not load the product photograph"));
    image.src = src;
  });
}

function pickMimeType(): string | undefined {
  const options = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
  return options.find((type) => MediaRecorder.isTypeSupported(type));
}
