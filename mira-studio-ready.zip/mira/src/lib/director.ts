import { chatWithMira, checkAi, composeFilm, generateStill, pollFilm, startFilm } from "./ai";
import { downscaleDataUri, fetchSampleAsDataUri, fileToDataUri } from "./compress";
import { intakeReady } from "./assistant";
import { useStudio } from "./store";
import { uid } from "./utils";
import { isFreeMode, localPlan, localStill, renderLocalFilm } from "./free-mode";

export async function bootAi() {
  const free = isFreeMode();
  useStudio.getState().setFreeMode(free);
  if (free) {
    useStudio.getState().setAiOk(false);
    return;
  }
  try {
    const r = await checkAi();
    useStudio.getState().setAiOk(r.ok);
  } catch {
    useStudio.getState().setAiOk(false);
  }
}

export async function ingestFile(file: File) {
  const dataUri = await fileToDataUri(file, 1280);
  const s = useStudio.getState();
  s.setImage(dataUri, file.name);
  await sendToMira(`I've added a product photograph${file.name ? ` (${file.name})` : ""}.`, {
    withImage: true,
  });
}

export async function runSampleDemo() {
  const dataUri = await fetchSampleAsDataUri("/sample-serum.jpg");
  const s = useStudio.getState();
  s.setImage(dataUri, "sample-serum.jpg");
  s.patchIntake({
    productName: "Aurora Vitamin C Serum",
    form: "liquid",
    look: "Smoked-amber glass dropper bottle, matte black cap, cream label, thin golden serum inside that catches light.",
    claims: "Dermatologist-formulated\n10% Vitamin C",
    surface: "pale veined marble under soft daylight",
    duration: 10,
    aspect: "9:16",
  });
  s.addMessage({ role: "user", text: "Run the full sample demo." });
  await writePlan();
  await shootStill();
  await animateStill();
}

export async function ingestSample() {
  const dataUri = await fetchSampleAsDataUri("/sample-serum.jpg");
  const s = useStudio.getState();
  s.setImage(dataUri, "sample-serum.jpg");
  s.patchIntake({
    productName: s.intake.productName || "Aurora Vitamin C Serum",
    form: s.intake.form || "rigid",
    look:
      s.intake.look ||
      "Smoked-amber glass dropper bottle, matte black cap, cream label, thin golden serum inside that catches light.",
    claims: s.intake.claims || "Dermatologist-formulated\n10% Vitamin C",
    surface: s.intake.surface || "pale veined marble under soft daylight",
  });
  s.addMessage({
    role: "user",
    text: "Use the sample bottle.",
  });
  await sendToMira(
    "Use this sample product: Aurora Vitamin C Serum, a rigid amber glass dropper bottle. Claims I may put on screen: Dermatologist-formulated / 10% Vitamin C. Duration 10s, 9:16 unless I change it. Look at the photo and continue.",
    { withImage: true, silentUser: true },
  );
}

export async function sendToMira(text: string, opts?: { withImage?: boolean; silentUser?: boolean }) {
  const s = useStudio.getState();
  const history = s.messages
    .filter((m) => m.id !== "open")
    .slice(-10)
    .map((m) => ({ role: m.role, text: m.text }));
  if (!opts?.silentUser) {
    s.addMessage({ role: "user", text });
  }
  if (s.freeMode) {
    s.setBusy("Planning locally");
    s.setError(null);
    try {
      const lower = text.toLowerCase();
      const patch: Partial<typeof s.intake> = {};
      if (!s.intake.productName && text.trim()) patch.productName = text.split(/[.!?]/)[0].slice(0, 60).trim();
      if (!s.intake.form) {
        if (/serum|oil|drink|juice|liquid/.test(lower)) patch.form = "liquid";
        else if (/cream|paste|balm|gel/.test(lower)) patch.form = "spread";
        else if (/shirt|dress|cloth|fabric|apparel/.test(lower)) patch.form = "fabric";
        else if (/jewell|ring|necklace|bracelet|earring/.test(lower)) patch.form = "jewellery";
        else patch.form = "rigid";
      }
      if (!s.intake.look && (opts?.withImage || s.imageDataUri)) patch.look = "Keep the original product shape, packaging, colour and material faithful to the photograph.";
      if (!s.intake.claims) patch.claims = "Product detail";
      if (/15\s*s|15 sec|15 second/.test(lower)) patch.duration = 15;
      else if (/6\s*s|6 sec|6 second/.test(lower)) patch.duration = 6;
      if (/square|1:1/.test(lower)) patch.aspect = "1:1";
      else if (/wide|16:9|youtube/.test(lower)) patch.aspect = "16:9";
      s.patchIntake(patch);
      const next = { ...s.intake, ...patch };
      const ready = intakeReady(next, Boolean(s.imageDataUri));
      s.addMessage({
        role: "assistant",
        text: ready
          ? "Free local mode is ready. I can build the shot plan, create a preview still from your photograph, and render a lightweight local video without API credits."
          : "Free local mode is active. Add the product photograph and a few product details; the studio will keep everything on this device.",
        suggestions: ready ? ["Write the shot plan", "Vertical, ten seconds"] : ["Use the sample bottle", "It's a serum in glass"],
        actions: ready ? [{ id: uid("a"), label: "Write the shot plan", kind: "plan" as const }] : undefined,
      });
    } finally {
      useStudio.getState().setBusy(null);
    }
    return;
  }

  if (s.aiOk === false) {
    s.addMessage({
      role: "assistant",
      text: "Cloud AI is unavailable. Turn off free mode and configure an xAI API key only if you want paid Grok API generation.",
    });
    return;
  }
  s.setBusy("Listening");
  s.setError(null);
  try {
    const vision = opts?.withImage && s.imageDataUri
      ? await downscaleDataUri(s.imageDataUri, 768, 0.7).catch(() => null)
      : null;
    const result = await Promise.race([
      chatWithMira({
        data: {
          history,
          userText: text,
          intake: s.intake,
          hasImage: Boolean(s.imageDataUri),
          imageDataUri: vision,
        },
      }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("Mira took too long to reply. Try again.")), 50_000),
      ),
    ]);
    s.patchIntake(result.intakePatch);
    const ready = intakeReady({ ...s.intake, ...result.intakePatch }, Boolean(s.imageDataUri));
    const actions = ready
      ? [{ id: uid("a"), label: "Write the shot plan", kind: "plan" as const }]
      : undefined;
    s.addMessage({
      role: "assistant",
      text: result.message,
      suggestions: result.suggestions,
      actions,
    });
  } catch (err) {
    s.addMessage({
      role: "assistant",
      text: err instanceof Error ? err.message : "I couldn't reach the studio just then. Try again.",
    });
  } finally {
    useStudio.getState().setBusy(null);
  }
}

export async function writePlan() {
  const s = useStudio.getState();
  if (!s.imageDataUri) {
    s.addMessage({
      role: "assistant",
      text: "I need a clean product photograph before I write a plan.",
    });
    return;
  }
  if (!s.intake.productName || !s.intake.form || !s.intake.look || !s.intake.claims) {
    s.addMessage({
      role: "assistant",
      text: "I still need the product name, what it physically is, a close visual detail, and the claims I may put on screen.",
    });
    return;
  }
  s.setBusy("Writing the plan");
  s.setError(null);
  try {
    if (s.freeMode) {
      const plan = localPlan(s.intake);
      s.setPlan(plan);
      const lines = plan.setups.map((x, i) => `${i + 1}. ${x.family} · ${x.seconds}s — ${x.action}`).join("\n");
      s.addMessage({
        role: "assistant",
        text: `Free local shot plan for ${plan.productName}. ${plan.setups.length} setups, ${plan.duration}s, ${plan.aspect}.\n\n${lines}\n\nNo API call was made. The still and preview film can be rendered on this device.`,
        actions: [{ id: uid("a"), label: "Shoot the still", kind: "still" }],
      });
      return;
    }
    const ledger = s.films
      .slice(0, 6)
      .map((f) => f.productName)
      .join(", ");
    const plan = await composeFilm({
      data: {
        intake: s.intake,
        imageDataUri: s.imageDataUri,
        ledgerNote: ledger,
      },
    });
    s.setPlan(plan);
    const lines = plan.setups
      .map((x, i) => `${i + 1}. ${x.family} · ${x.seconds}s — ${x.action}`)
      .join("\n");
    s.addMessage({
      role: "assistant",
      text: `Here's the plan for ${plan.productName}. ${plan.setups.length} setups, ${plan.duration}s, ${plan.aspect}. ${plan.archetype} / ${plan.pacing}.\n\n${lines}\n\nNothing is generated until you approve a still. A wrong still is cheap; a wrong clip is not.`,
      actions: [{ id: uid("a"), label: "Shoot the still", kind: "still" }],
    });
  } catch (err) {
    s.fail(err instanceof Error ? err.message : "The plan failed");
    s.addMessage({
      role: "assistant",
      text: err instanceof Error ? err.message : "I couldn't write the plan.",
    });
  } finally {
    useStudio.getState().setBusy(null);
  }
}

export async function shootStill() {
  const s = useStudio.getState();
  if (!s.plan || !s.imageDataUri) return;
  s.setBusy("Shooting the still");
  s.setError(null);
  try {
    if (s.freeMode) {
      s.setStill(localStill(s.imageDataUri));
      s.addMessage({
        role: "assistant",
        text: "Still approved in free local mode. This is the original reference photograph, preserved without sending it to an AI API.",
        actions: [{ id: uid("a"), label: "Animate this still", kind: "animate" }],
      });
      return;
    }
    const { dataUri } = await generateStill({
      data: {
        prompt: s.plan.stillPrompt,
        imageDataUri: s.imageDataUri,
        aspectRatio: s.plan.aspect,
      },
    });
    s.setStill(dataUri);
    s.addMessage({
      role: "assistant",
      text: "Still is on the stage. Check the product, the surface, and whether the label is right. If it's wrong, tell me what to change and I'll reshoot the still — not the film.",
      actions: [{ id: uid("a"), label: "Animate this still", kind: "animate" }],
    });
  } catch (err) {
    s.fail(err instanceof Error ? err.message : "The still failed");
    s.addMessage({
      role: "assistant",
      text: err instanceof Error ? err.message : "The still didn't come back.",
    });
  } finally {
    useStudio.getState().setBusy(null);
  }
}

export async function animateStill() {
  const s = useStudio.getState();
  if (!s.plan || !s.stillDataUri) return;
  s.setBusy("Animating");
  s.setError(null);
  try {
    if (s.freeMode) {
      s.setRendering("local");
      s.addMessage({ role: "assistant", text: `Rendering a local ${s.plan.duration}s preview — no Grok/xAI credits are used.` });
      const url = await renderLocalFilm({
        imageDataUri: s.stillDataUri,
        duration: s.plan.duration,
        aspect: s.plan.aspect,
        productName: s.plan.productName,
      });
      s.setVideo(url);
      s.addMessage({ role: "assistant", text: "Local film is ready. Use Save film to export it from this browser." });
      return;
    }
    const { requestId } = await startFilm({
      data: {
        prompt: s.plan.filmPrompt,
        stillDataUri: s.stillDataUri,
        duration: s.plan.duration,
        aspectRatio: s.plan.aspect,
      },
    });
    s.setRendering(requestId);
    s.addMessage({
      role: "assistant",
      text: `Motion is running — ${s.plan.duration}s at 720p. I'll put the film on the stage when it's ready.`,
    });
    await waitForFilm(requestId);
  } catch (err) {
    s.fail(err instanceof Error ? err.message : "The film failed");
    s.addMessage({
      role: "assistant",
      text: err instanceof Error ? err.message : "The film didn't start.",
    });
  }
}

async function waitForFilm(requestId: string) {
  const started = Date.now();
  const limit = 4 * 60 * 1000;
  while (Date.now() - started < limit) {
    await sleep(4000);
    const status = await pollFilm({ data: { requestId } });
    if (status.status === "done" && status.url) {
      useStudio.getState().setVideo(status.url);
      useStudio.getState().addMessage({
        role: "assistant",
        text: "The film is on the stage. Watch it through once. If something is wrong, list every fault — I'll reshoot from this still, not from scratch.",
      });
      useStudio.getState().setBusy(null);
      return;
    }
    if (status.status === "failed" || status.status === "expired") {
      throw new Error(status.error || `Generation ${status.status}`);
    }
  }
  throw new Error("The film took too long. Try animating the still again.");
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function handleAction(kind: string, label?: string) {
  if (kind === "plan") return writePlan();
  if (kind === "still") return shootStill();
  if (kind === "animate") return animateStill();
  if (kind === "chip" && label) return sendToMira(label);
}
