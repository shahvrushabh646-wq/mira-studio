export const FORMS = [
  "rigid",
  "liquid",
  "spread",
  "powder",
  "pieces",
  "fabric",
  "jewellery",
] as const;

export type ProductForm = (typeof FORMS)[number];

export const FORM_LABELS: Record<ProductForm, string> = {
  rigid: "Rigid object",
  liquid: "Liquid",
  spread: "Cream / paste",
  powder: "Powder",
  pieces: "Solid pieces",
  fabric: "Fabric / apparel",
  jewellery: "Jewellery",
};

export const DURATIONS = [6, 10, 15] as const;
export type Duration = (typeof DURATIONS)[number];

export const ASPECTS = ["9:16", "1:1", "16:9"] as const;
export type Aspect = (typeof ASPECTS)[number];

export const ASPECT_LABELS: Record<Aspect, string> = {
  "9:16": "Vertical · Reels",
  "1:1": "Square · feed",
  "16:9": "Wide · YouTube",
};

export const PACING = [
  "fast-cut-energy",
  "speed-ramp",
  "product-spin",
  "snap-macro",
  "drone-sweep",
  "stop-motion-pop",
] as const;

export type Pacing = (typeof PACING)[number];

export type ActionFamily =
  | "reveal"
  | "open"
  | "unbox"
  | "impact"
  | "orbit"
  | "use"
  | "spread"
  | "macro"
  | "consume"
  | "transform"
  | "arrange"
  | "pullback"
  | "pour"
  | "stack"
  | "splash"
  | "drop"
  | "freeze"
  | "swirl"
  | "slice"
  | "dust"
  | "rise"
  | "tumble"
  | "lineup"
  | "shadow"
  | "squeeze"
  | "pourout"
  | "crunch"
  | "wear"
  | "fold"
  | "click"
  | "flip";

export const CAMERAS = [
  "slow 90-degree arc at product height",
  "full 360-degree orbit at a steady cinematic pace, product centred, gimbal-smooth, snapping to a locked hero frame",
  "fast push in to a macro framing",
  "pull back to the whole surface",
  "top-down drop onto the set",
  "low slider at product height",
  "tilt up the front face",
  "crash zoom on a single detail",
  "overhead spin",
  "rack focus from foreground texture",
  "tabletop drone-style glide across the counter",
  "180 degree arc",
] as const;

const FORBIDDEN: Record<ProductForm, ActionFamily[]> = {
  rigid: ["pourout", "crunch", "stack", "fold", "wear", "pour", "spread", "swirl", "splash", "dust", "squeeze"],
  liquid: ["pourout", "crunch", "stack", "dust", "fold", "wear", "click", "flip"],
  spread: ["pourout", "crunch", "stack", "dust", "fold", "wear", "click"],
  powder: ["crunch", "slice", "stack", "fold", "wear", "click", "squeeze"],
  pieces: ["pour", "squeeze", "swirl", "splash", "spread", "fold", "wear"],
  fabric: ["pour", "spread", "crunch", "dust", "splash", "pourout", "stack", "click"],
  jewellery: ["pour", "spread", "crunch", "dust", "pourout", "fold", "splash", "squeeze"],
};

const PREFERRED: Record<ProductForm, ActionFamily[]> = {
  rigid: ["orbit", "reveal", "macro", "click", "open", "flip", "shadow", "pullback"],
  liquid: ["orbit", "pour", "drop", "macro", "reveal", "splash", "swirl", "pullback"],
  spread: ["reveal", "spread", "swirl", "macro", "squeeze", "orbit", "pullback"],
  powder: ["reveal", "pour", "dust", "macro", "transform", "orbit"],
  pieces: ["reveal", "pourout", "tumble", "stack", "macro", "orbit", "arrange"],
  fabric: ["reveal", "fold", "wear", "macro", "orbit", "pullback"],
  jewellery: ["orbit", "macro", "reveal", "shadow", "flip", "wear", "pullback"],
};

export type Setup = {
  family: ActionFamily;
  seconds: number;
  action: string;
  camera: string;
  light: string;
};

export type ShotPlan = {
  productName: string;
  form: ProductForm;
  archetype: string;
  pacing: Pacing;
  duration: Duration;
  aspect: Aspect;
  surface: string;
  productDescription: string;
  hook: string;
  valueAngle: string;
  families: ActionFamily[];
  setups: Setup[];
  onScreenText: {
    setupIndex: number;
    intro: string;
    accent: string;
    colour: string;
    placement: string;
  } | null;
  sound: string;
  stillPrompt: string;
  filmPrompt: string;
};

export type Intake = {
  productName: string;
  form: ProductForm | "";
  look: string;
  claims: string;
  duration: Duration;
  aspect: Aspect;
  surface: string;
  edible: boolean;
};

export const EMPTY_INTAKE: Intake = {
  productName: "",
  form: "",
  look: "",
  claims: "",
  duration: 10,
  aspect: "9:16",
  surface: "",
  edible: false,
};

export function setupCount(duration: Duration): number {
  if (duration <= 6) return 3;
  if (duration <= 10) return 3;
  return 4;
}

export function allowedFamilies(form: ProductForm, edible: boolean): ActionFamily[] {
  const banned = new Set(FORBIDDEN[form]);
  const preferred = PREFERRED[form];
  const extra: ActionFamily[] = edible ? ["consume", "use"] : [];
  const pool: ActionFamily[] = [
    ...preferred,
    ...extra,
    "reveal",
    "macro",
    "orbit",
    "pullback",
    "shadow",
  ];
  return [...new Set(pool)].filter((f) => !banned.has(f));
}

export function splitClaims(raw: string): { intro: string; accent: string } | null {
  const text = raw.trim();
  if (!text) return null;
  const parts = text
    .split(/[\n•|;]+/)
    .map((s) => s.trim())
    .filter(Boolean);
  if (parts.length === 0) return null;
  if (parts.length === 1) {
    const words = parts[0].split(/\s+/);
    if (words.length <= 4) return { intro: "", accent: parts[0] };
    return { intro: words.slice(0, 3).join(" "), accent: words.slice(3).join(" ") };
  }
  return { intro: parts[0], accent: parts[1] };
}

export function defaultSurface(form: ProductForm): string {
  switch (form) {
    case "liquid":
    case "spread":
      return "pale veined marble under soft daylight";
    case "fabric":
      return "a seamless warm stone sweep";
    case "jewellery":
      return "dark honed slate with a single rim light";
    case "powder":
    case "pieces":
      return "a warm oak board, clean and unstyled";
    default:
      return "a matte charcoal studio sweep";
  }
}

export function buildStillPrompt(plan: ShotPlan): string {
  const s1 = plan.setups[0];
  const text = plan.onScreenText
    ? `Reserved negative space ${plan.onScreenText.placement}. Optional faint on-screen words "${plan.onScreenText.intro}" small and "${plan.onScreenText.accent}" large in ${plan.onScreenText.colour}, sitting directly on the scene with no coloured chip, panel or banner behind them.`
    : "No on-screen text, letters, numbers, watermarks or captions.";
  return [
    `A single cinematic still photograph, the opening frame of a ${plan.aspect} product film for ${plan.productName}.`,
    `The product from the reference image must keep its exact shape, materials, colour, label and branding — do not redesign it.`,
    `Place it on ${plan.surface}. Do not carry over the table, backdrop or surface from the reference photograph.`,
    plan.productDescription,
    s1
      ? `Composition: ${s1.action} held as a still. Camera suggestion: ${s1.camera}. Light: ${s1.light}.`
      : "Hero three-quarter product framing.",
    text,
    `No hands, no people, no logo, no watermark, no brand mark of any kind invented by you. No extra props beyond a contained product scene. Photoreal, editorial, expensive.`,
  ].join(" ");
}

export function buildFilmPrompt(plan: ShotPlan): string {
  const n = plan.setups.length;
  const setups = plan.setups
    .map((s, i) => {
      return `[SETUP ${i + 1} — ${s.family}]  ~${s.seconds}s
${s.action}
Camera: ${s.camera}.
Light: ${s.light}.`;
    })
    .join("\n\n");

  const textBlock = plan.onScreenText
    ? `Setup ${plan.onScreenText.setupIndex + 1}: the words "${plan.onScreenText.intro}" appear small above, then "${plan.onScreenText.accent}" appears large and bold beneath it, in ${plan.onScreenText.colour}, positioned ${plan.onScreenText.placement}. Reserve space for it. No other text, letters, numbers, labels, watermarks or captions appear anywhere in the film at any point. No coloured box, panel, chip or banner behind any text.`
    : `No on-screen text, letters, numbers, labels, watermarks or captions appear anywhere in the film at any point.`;

  return `[FORMAT]
A ${plan.duration}-second ${plan.aspect} product film for ${plan.productName}.
${plan.pacing} energy. ${n} distinct setups, cutting between them.

[THE FIXED SET]
Everything happens on ${plan.surface}. The ${plan.productName} is present from the start.
Nothing else appears at any point. Nothing arrives without being shown arriving.

[THE PRODUCT]
${plan.productDescription} The product's branding must stay legible and must not change between setups.

${setups}

[ON-SCREEN TEXT]
${textBlock}

[SOUND]
${plan.sound}
There is no voiceover, no presenter, and no spoken words.

[ENDING]
The film ends on the product settled, resolved rather than stopping mid-action.
Then fade gently and evenly to black over the last half second.

[DO NOT]
No hands or people in frame. No logo, no watermark, no brand mark of any kind.
No text beyond the words named above. No slow motion.
No cuts to black mid-film.
The surface and background are only what is described above. Do not carry over the surface, table or backdrop from the reference photograph.`;
}

export function secondsForSetups(duration: Duration, count: number): number[] {
  const base = Math.floor(duration / count);
  const leftover = duration - base * count;
  const out = Array.from({ length: count }, () => base);
  // rising length curve — last setups a little longer
  for (let i = 0; i < leftover; i++) out[count - 1 - i] += 1;
  if (out[0] < 2) out[0] = 2;
  return out;
}
