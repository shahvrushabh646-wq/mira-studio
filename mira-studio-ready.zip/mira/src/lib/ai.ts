import { createServerFn } from "@tanstack/react-start";
import { assemblePlan, describeIntake, MIRA_SYSTEM, parseAssistant, PLAN_SYSTEM } from "./assistant";
import type { Intake } from "./film";

export const checkAi = createServerFn({ method: "POST" }).handler(async () => {
  const { hasXaiKey } = await import("./xai.server.ts");
  return { ok: hasXaiKey() };
});

type ChatInput = {
  history: { role: "user" | "assistant"; text: string }[];
  userText: string;
  intake: Intake;
  hasImage: boolean;
  imageDataUri?: string | null;
};

export const chatWithMira = createServerFn({ method: "POST" })
  .validator((input: ChatInput) => input)
  .handler(async ({ data }) => {
    const { chatCompletions } = await import("./xai.server.ts");
    const history = data.history.slice(-10).map((m) => ({
      role: m.role,
      content: m.text,
    }));

    const userContent: Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string } }
    > = [
      {
        type: "text",
        text: `${data.userText}\n\n[Current intake]\n${describeIntake(data.intake, data.hasImage)}`,
      },
    ];
    if (data.imageDataUri) {
      userContent.push({
        type: "image_url",
        image_url: { url: data.imageDataUri },
      });
    }

    const raw = await chatCompletions({
      json: true,
      maxTokens: 900,
      messages: [
        { role: "system", content: MIRA_SYSTEM },
        ...history,
        { role: "user", content: userContent },
      ],
    });
    return parseAssistant(raw);
  });

type PlanInput = {
  intake: Intake;
  imageDataUri?: string | null;
  ledgerNote?: string;
};

export const composeFilm = createServerFn({ method: "POST" })
  .validator((input: PlanInput) => input)
  .handler(async ({ data }) => {
    const { chatCompletions } = await import("./xai.server.ts");
    const { allowedFamilies, setupCount } = await import("./film.ts");
    const form = data.intake.form || "rigid";
    const n = setupCount(data.intake.duration);
    const allowed = allowedFamilies(form, data.intake.edible);

    const userContent: Array<
      | { type: "text"; text: string }
      | { type: "image_url"; image_url: { url: string } }
    > = [
      {
        type: "text",
        text: `Design the film.

${describeIntake(data.intake, Boolean(data.imageDataUri))}
setups required: ${n}
allowed families: ${allowed.join(", ")}
recent films (avoid overlap): ${data.ledgerNote || "none yet — say so if you lean on a default"}

Write concrete actions from the photograph if attached. Do not invent claims.`,
      },
    ];
    if (data.imageDataUri) {
      userContent.push({
        type: "image_url",
        image_url: { url: data.imageDataUri },
      });
    }

    const raw = await chatCompletions({
      json: true,
      maxTokens: 1400,
      messages: [
        { role: "system", content: PLAN_SYSTEM },
        { role: "user", content: userContent },
      ],
    });
    return assemblePlan(data.intake, raw);
  });

type StillInput = {
  prompt: string;
  imageDataUri: string;
  aspectRatio: string;
};

export const generateStill = createServerFn({ method: "POST" })
  .validator((input: StillInput) => input)
  .handler(async ({ data }) => {
    const { editImage } = await import("./xai.server.ts");
    const dataUri = await editImage({
      prompt: data.prompt,
      imageDataUri: data.imageDataUri,
      aspectRatio: data.aspectRatio,
    });
    return { dataUri };
  });

type VideoInput = {
  prompt: string;
  stillDataUri: string;
  duration: number;
  aspectRatio: string;
};

export const startFilm = createServerFn({ method: "POST" })
  .validator((input: VideoInput) => input)
  .handler(async ({ data }) => {
    const { startVideo } = await import("./xai.server.ts");
    const requestId = await startVideo({
      prompt: data.prompt,
      imageDataUri: data.stillDataUri,
      duration: data.duration,
      aspectRatio: data.aspectRatio,
    });
    return { requestId };
  });

export const pollFilm = createServerFn({ method: "POST" })
  .validator((input: { requestId: string }) => input)
  .handler(async ({ data }) => {
    const { pollVideo } = await import("./xai.server.ts");
    return pollVideo(data.requestId);
  });
