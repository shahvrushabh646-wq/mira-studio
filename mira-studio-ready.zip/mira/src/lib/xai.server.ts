const XAI = "https://api.x.ai/v1";

function apiKey(): string | null {
  const k = process.env.XAI_API_KEY?.trim();
  return k || null;
}

export function hasXaiKey(): boolean {
  return Boolean(apiKey());
}

async function xaiFetch(path: string, init: RequestInit): Promise<Response> {
  const key = apiKey();
  if (!key) throw new Error("AI is not available in this environment");
  const res = await fetch(`${XAI}${path}`, {
    ...init,
    signal: init.signal ?? AbortSignal.timeout(55_000),
    headers: {
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  return res;
}

async function readError(res: Response): Promise<string> {
  const text = await res.text();
  let message = text.slice(0, 400) || `xAI API error ${res.status}`;
  try {
    const j = JSON.parse(text) as {
      error?: { message?: string } | string;
      code?: string;
    };
    if (typeof j.error === "string") message = j.error;
    else if (j.error?.message) message = j.error.message;
    if (j.code === "personal-team-blocked:spending-limit" || /credits|subscription/i.test(message)) {
      return "The studio is out of generation credits right now. The photograph can stay on the stage — try again when credits are restored.";
    }
  } catch {
    /* fall through */
  }
  if (res.status === 403) {
    return "The studio is out of generation credits right now. The photograph can stay on the stage — try again when credits are restored.";
  }
  return message;
}

export type ChatTurn = {
  role: "system" | "user" | "assistant";
  content: string | Array<{ type: "text"; text: string } | { type: "image_url"; image_url: { url: string } }>;
};

export async function chatCompletions(input: {
  messages: ChatTurn[];
  json?: boolean;
  maxTokens?: number;
}): Promise<string> {
  const res = await xaiFetch("/chat/completions", {
    method: "POST",
    body: JSON.stringify({
      model: "grok-4.5",
      messages: input.messages,
      max_tokens: input.maxTokens ?? 1400,
      temperature: 0.5,
      ...(input.json ? { response_format: { type: "json_object" } } : {}),
    }),
  });
  if (!res.ok) throw new Error(await readError(res));
  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  return body.choices?.[0]?.message?.content ?? "";
}

export async function editImage(input: {
  prompt: string;
  imageDataUri: string;
  aspectRatio?: string;
}): Promise<string> {
  const body: Record<string, unknown> = {
    model: "grok-imagine-image-2.0",
    prompt: input.prompt,
    image: { url: input.imageDataUri, type: "image_url" },
    response_format: "url",
  };
  if (input.aspectRatio) body.aspect_ratio = input.aspectRatio;

  const res = await xaiFetch("/images/edits", {
    method: "POST",
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(await readError(res));
  const json = (await res.json()) as { data?: { url?: string; b64_json?: string }[] };
  const first = json.data?.[0];
  if (first?.b64_json) return `data:image/jpeg;base64,${first.b64_json}`;
  if (first?.url) return urlToDataUri(first.url);
  throw new Error("The still came back empty");
}

export async function startVideo(input: {
  prompt: string;
  imageDataUri: string;
  duration: number;
  aspectRatio: string;
}): Promise<string> {
  const res = await xaiFetch("/videos/generations", {
    method: "POST",
    body: JSON.stringify({
      model: "grok-imagine-video-1.5",
      prompt: input.prompt,
      image: { url: input.imageDataUri },
      duration: input.duration,
      aspect_ratio: input.aspectRatio,
      resolution: "720p",
      generate_audio: true,
    }),
  });
  if (!res.ok) throw new Error(await readError(res));
  const json = (await res.json()) as { request_id?: string };
  if (!json.request_id) throw new Error("Video job did not start");
  return json.request_id;
}

export async function pollVideo(
  requestId: string,
): Promise<{ status: string; url?: string; error?: string }> {
  const res = await xaiFetch(`/videos/${encodeURIComponent(requestId)}`, {
    method: "GET",
  });
  if (!res.ok) throw new Error(await readError(res));
  const json = (await res.json()) as {
    status?: string;
    video?: { url?: string };
    error?: { message?: string } | string;
  };
  const status = json.status ?? "pending";
  const err =
    typeof json.error === "string" ? json.error : json.error?.message;
  return { status, url: json.video?.url, error: err };
}

async function urlToDataUri(url: string): Promise<string> {
  const res = await fetch(url);
  if (!res.ok) throw new Error("Could not fetch the generated still");
  const buf = Buffer.from(await res.arrayBuffer());
  const mime = res.headers.get("content-type") || "image/jpeg";
  return `data:${mime};base64,${buf.toString("base64")}`;
}
