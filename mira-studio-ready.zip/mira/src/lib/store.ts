import { create } from "zustand";
import { persist } from "zustand/middleware";
import { EMPTY_INTAKE, type Intake, type ShotPlan } from "./film";
import { uid } from "./utils";

export type Role = "user" | "assistant";

export type ChatAction = {
  id: string;
  label: string;
  kind: "plan" | "still" | "animate" | "chip";
};

export type ChatMessage = {
  id: string;
  role: Role;
  text: string;
  at: number;
  actions?: ChatAction[];
  suggestions?: string[];
};

export type SavedFilm = {
  id: string;
  productName: string;
  stillDataUri: string;
  videoUrl: string | null;
  aspect: string;
  duration: number;
  createdAt: number;
};

export type Phase = "intake" | "planned" | "still" | "rendering" | "ready" | "error";

type StudioState = {
  hydrated: boolean;
  aiOk: boolean | null;
  freeMode: boolean;
  phase: Phase;
  busy: string | null;
  error: string | null;
  intake: Intake;
  imageDataUri: string | null;
  imageName: string | null;
  plan: ShotPlan | null;
  stillDataUri: string | null;
  videoUrl: string | null;
  videoRequestId: string | null;
  messages: ChatMessage[];
  films: SavedFilm[];
  libraryOpen: boolean;
  setHydrated: (v: boolean) => void;
  setAiOk: (v: boolean) => void;
  setFreeMode: (v: boolean) => void;
  setBusy: (v: string | null) => void;
  setError: (v: string | null) => void;
  setLibraryOpen: (v: boolean) => void;
  patchIntake: (p: Partial<Intake>) => void;
  setImage: (dataUri: string, name?: string) => void;
  addMessage: (m: Omit<ChatMessage, "id" | "at"> & { id?: string }) => void;
  setPlan: (plan: ShotPlan) => void;
  setStill: (dataUri: string) => void;
  setRendering: (requestId: string) => void;
  setVideo: (url: string) => void;
  fail: (message: string) => void;
  newFilm: () => void;
  loadFilm: (id: string) => void;
  removeFilm: (id: string) => void;
};

function openingMessage(): ChatMessage {
  return {
    id: "open",
    role: "assistant",
    text: "Hello.\n\nI'm Mira — your personal film director. Drop a clean product photograph and I'll make a short film where the product performs. No presenter. No voiceover.\n\nTell me the name as it appears on the pack, what it physically is, and the claims I may put on screen.",
    at: Date.now(),
    suggestions: ["Use the sample bottle", "It's a serum in glass", "Vertical, ten seconds"],
  };
}

const initial = {
  hydrated: false,
  aiOk: null as boolean | null,
  freeMode: true,
  phase: "intake" as Phase,
  busy: null as string | null,
  error: null as string | null,
  intake: { ...EMPTY_INTAKE },
  imageDataUri: null as string | null,
  imageName: null as string | null,
  plan: null as ShotPlan | null,
  stillDataUri: null as string | null,
  videoUrl: null as string | null,
  videoRequestId: null as string | null,
  messages: [openingMessage()],
  films: [] as SavedFilm[],
  libraryOpen: false,
};

export const useStudio = create<StudioState>()(
  persist(
    (set, get) => ({
      ...initial,
      setHydrated: (v) => set({ hydrated: v }),
      setAiOk: (v) => set({ aiOk: v }),
      setFreeMode: (v) => set({ freeMode: v }),
      setBusy: (v) => set({ busy: v }),
      setError: (v) => set({ error: v }),
      setLibraryOpen: (v) => set({ libraryOpen: v }),
      patchIntake: (p) => set({ intake: { ...get().intake, ...p } }),
      setImage: (dataUri, name) =>
        set({
          imageDataUri: dataUri,
          imageName: name ?? "product.jpg",
          stillDataUri: null,
          videoUrl: null,
          videoRequestId: null,
          plan: null,
          phase: "intake",
          error: null,
        }),
      addMessage: (m) =>
        set({
          messages: [
            ...get().messages,
            { id: m.id ?? uid("m"), at: Date.now(), ...m },
          ],
        }),
      setPlan: (plan) =>
        set({
          plan,
          phase: "planned",
          error: null,
          intake: {
            ...get().intake,
            productName: plan.productName || get().intake.productName,
            form: plan.form || get().intake.form,
            surface: plan.surface,
          },
        }),
      setStill: (dataUri) => set({ stillDataUri: dataUri, phase: "still", error: null }),
      setRendering: (requestId) =>
        set({ videoRequestId: requestId, phase: "rendering", error: null }),
      setVideo: (url) => {
        const { plan, stillDataUri, films, intake } = get();
        const film: SavedFilm = {
          id: uid("film"),
          productName: plan?.productName || intake.productName || "Untitled",
          stillDataUri: stillDataUri || "",
          videoUrl: url,
          aspect: plan?.aspect || intake.aspect,
          duration: plan?.duration || intake.duration,
          createdAt: Date.now(),
        };
        const next = [film, ...films].slice(0, 8);
        set({ videoUrl: url, phase: "ready", films: next, busy: null });
      },
      fail: (message) => set({ error: message, phase: "error", busy: null }),
      newFilm: () =>
        set({
          phase: "intake",
          busy: null,
          error: null,
          intake: { ...EMPTY_INTAKE },
          imageDataUri: null,
          imageName: null,
          plan: null,
          stillDataUri: null,
          videoUrl: null,
          videoRequestId: null,
          messages: [openingMessage()],
          libraryOpen: false,
        }),
      loadFilm: (id) => {
        const film = get().films.find((f) => f.id === id);
        if (!film) return;
        set({
          stillDataUri: film.stillDataUri,
          videoUrl: film.videoUrl,
          phase: film.videoUrl ? "ready" : "still",
          libraryOpen: false,
          error: null,
        });
      },
      removeFilm: (id) => set({ films: get().films.filter((f) => f.id !== id) }),
    }),
    {
      name: "mira-studio-v1",
      partialize: (s) => ({
        films: s.films,
      }),
    },
  ),
);
