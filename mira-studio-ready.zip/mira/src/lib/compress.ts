export async function downscaleDataUri(
  dataUri: string,
  maxEdge = 768,
  quality = 0.72,
): Promise<string> {
  const res = await fetch(dataUri);
  const blob = await res.blob();
  return compressImage(blob, maxEdge, quality);
}
