# Mira — Grok + Vercel free deployment

## Grok Build / Grok Code
1. Import this workspace into Grok Build.
2. Keep `VITE_MIRA_FREE_MODE=true` (the code defaults to free mode even if the variable is absent).
3. Run the app.
4. Upload a product photo → fill the brief → Write plan → Shoot still → Animate still.
5. The plan and preview film are rendered locally in the browser. No xAI API key is needed.
6. The exported free video is WebM (browser-native), not MP4; this avoids any paid video encoder/service.

## Vercel Hobby
1. Push the workspace to your GitHub repository.
2. Import the repository into Vercel.
3. Use the included `vercel.json` and the default build command.
4. Do **not** add `XAI_API_KEY` if you want to guarantee zero xAI API spend.
5. Keep `VITE_MIRA_FREE_MODE=true` (or omit it; free mode is the default).
6. No database, authentication, or paid AI service is required for the free workflow.

## Important
Free mode is a local renderer, not free AI generation. Real Grok image/video generation requires xAI API usage and xAI documents that API usage is deducted from prepaid credits or billed. If you later want real Grok generation, explicitly opt in by setting `VITE_MIRA_FREE_MODE=false` and supplying `XAI_API_KEY`.
