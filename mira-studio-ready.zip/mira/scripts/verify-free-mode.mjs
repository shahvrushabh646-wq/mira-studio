#!/usr/bin/env node
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(fileURLToPath(new URL('.', import.meta.url)), '..');
const env = await readFile(join(root, '.env.example'), 'utf8');
const free = env.match(/VITE_MIRA_FREE_MODE\s*=\s*true/);
if (!free) throw new Error('Free mode is not enabled by default');

const director = await readFile(join(root, 'src/lib/director.ts'), 'utf8');
const freeMode = await readFile(join(root, 'src/lib/free-mode.ts'), 'utf8');
if (!director.includes('if (s.freeMode)')) throw new Error('Free-mode guard missing from director');
if (!freeMode.includes('renderLocalFilm')) throw new Error('Local film renderer missing');

console.log('Free-mode verification passed: no xAI API call is required by the default workflow.');
